﻿using System;
using System.Linq;
using System.Windows;
using System.Data.Entity;
using OurDecor.Model;

namespace OurDecor
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadProducts(); // Загрузка продуктов при запуске
        }

        // Основной метод загрузки продуктов из базы данных
        private void LoadProducts()
        {
            try
            {
                using (var db = new WallpaperProductionEntities1())
                {
                    // Загрузка продуктов с включенными связанными данными
                    var productsFromDb = db.Product
                        .Include("ProductType") // Тип продукта
                        .Include("ProductMaterial.Material.MaterialType") // Материалы и их типы
                        .Include("ProductMaterial")
                        .ToList();

                    // Преобразование в ViewModel для отображения
                    var productViewModels = productsFromDb
                        .Select(p =>
                        {
                            // Расчет стоимости материалов с учетом дефектов
                            double materialsCost = 0.0;
                            foreach (var pm in p.ProductMaterial)
                            {
                                var material = pm.Material;
                                if (material == null) continue;
                                double itemCost = material.Price * pm.Count *
                                                  (1.0 + (material.MaterialType?.DefectPercent ?? 0) / 100.0);
                                materialsCost += itemCost;
                            }

                            // Расчет итоговой стоимости с коэффициентом типа продукта
                            double coef = p.ProductType?.Coefficient ?? 1.0;
                            double totalCost = Math.Round(materialsCost * coef, 2);
                            if (totalCost < 0) totalCost = 0;

                            // Создание ViewModel для отображения
                            return new ProductViewModel
                            {
                                ProductID = p.ProductID,
                                ProductTypeName = p.ProductType?.Name ?? "",
                                Name = p.Name,
                                Article = p.Article,
                                MinCost = Math.Round(Math.Max(0, p.MinCost), 2),
                                Width = Math.Round(Math.Max(0, p.Width), 2),
                                TotalCost = totalCost
                            };
                        })
                        .ToList();

                    // Установка источника данных для ItemsControl
                    ProductsItemsControl.ItemsSource = productViewModels;
                    StatusText.Text = "Загрузка завершена успешно";
                }
            }
            catch (Exception ex)
            {
                // Обработка ошибок загрузки
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Обработчик клика по кнопке добавления продукта
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddEditProductWindow();
            addWindow.Owner = this;
            if (addWindow.ShowDialog() == true)
                LoadProducts(); // Перезагрузка после добавления
        }

        // Обработчик клика по карточке продукта для редактирования
        private void ProductCard_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var border = sender as System.Windows.Controls.Border;
            if (border?.DataContext is ProductViewModel vm)
            {
                var editWindow = new AddEditProductWindow(vm.ProductID);
                editWindow.Owner = this;
                if (editWindow.ShowDialog() == true)
                    LoadProducts(); // Перезагрузка после редактирования
            }
        }

        // Обработчик клика по кнопке расчета материалов
        private void CalculateMaterialsButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.DataContext is ProductViewModel vm)
            {
                var inputWindow = new InputParametersWindow();
                inputWindow.Owner = this;
                if (inputWindow.ShowDialog() == true)
                {
                    // Получение параметров из диалогового окна
                    int productQty = inputWindow.ProductQuantity;
                    double param1 = inputWindow.Param1;
                    double param2 = inputWindow.Param2;

                    // Расчет и отображение необходимых материалов
                    ShowRequiredMaterialsForProduct(vm.ProductID, productQty, param1, param2);
                }
            }
        }

        // Метод расчета и отображения необходимых материалов для продукта
        private void ShowRequiredMaterialsForProduct(int productId, int productQty, double param1, double param2)
        {
            using (var db = new WallpaperProductionEntities1())
            {
                // Загрузка продукта с материалами
                var product = db.Product
                                .Include("ProductType")
                                .Include("ProductMaterial.Material.MaterialType")
                                .FirstOrDefault(p => p.ProductID == productId);
                if (product == null) return;

                // Расчет необходимого количества для каждого материала
                foreach (var pm in product.ProductMaterial)
                {
                    int toBuy = MaterialCalculator.CalculateRequiredMaterial(
                        product.MaterialTypeID,
                        pm.Material.MaterialTypeID,
                        productQty,
                        param1,
                        param2,
                        pm.Count
                    );

                    // Показ результата расчета
                    MessageBox.Show($"Материал: {pm.Material.Name}\nНеобходимо закупить: {toBuy}",
                                    "Расчет закупки", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }

    // ViewModel для отображения продукта в интерфейсе
    public class ProductViewModel
    {
        public int ProductID { get; set; } // ID продукта
        public string ProductTypeName { get; set; } // Название типа продукта
        public string Name { get; set; } // Название продукта
        public string Article { get; set; } // Артикул
        public double MinCost { get; set; } // Минимальная стоимость
        public double Width { get; set; } // Ширина
        public double TotalCost { get; set; } // Итоговая стоимость
    }
}